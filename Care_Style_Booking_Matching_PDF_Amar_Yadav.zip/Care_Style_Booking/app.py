import os, sqlite3
from datetime import date, datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, g, abort
from werkzeug.security import generate_password_hash, check_password_hash

BASE=os.path.dirname(os.path.abspath(__file__))
DB=os.environ.get('DATABASE_PATH',os.path.join(BASE,'booking.db'))
app=Flask(__name__)
app.secret_key=os.environ.get('SECRET_KEY','local-demo-only-change-this-before-hosting')
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE')=='1')

def db():
    if 'conn' not in g:
        g.conn=sqlite3.connect(DB,timeout=15)
        g.conn.row_factory=sqlite3.Row
        g.conn.execute('PRAGMA foreign_keys=ON')
    return g.conn

@app.teardown_appcontext
def cleanup(error):
    conn=g.pop('conn',None)
    if conn: conn.close()

def init_db():
    os.makedirs(os.path.dirname(os.path.abspath(DB)),exist_ok=True)
    with sqlite3.connect(DB) as c:
        c.executescript('''
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS providers(id INTEGER PRIMARY KEY,name TEXT NOT NULL,category TEXT NOT NULL,specialty TEXT NOT NULL,description TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS services(id INTEGER PRIMARY KEY,provider_id INTEGER NOT NULL REFERENCES providers(id),name TEXT NOT NULL,price INTEGER NOT NULL,duration INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS appointments(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),provider_id INTEGER NOT NULL REFERENCES providers(id),service_id INTEGER NOT NULL REFERENCES services(id),booking_date TEXT NOT NULL,booking_time TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'Confirmed',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE UNIQUE INDEX IF NOT EXISTS unique_active_slot ON appointments(provider_id,booking_date,booking_time) WHERE status='Confirmed';
        ''')
        if c.execute('SELECT COUNT(*) FROM providers').fetchone()[0]==0:
            c.executemany('INSERT INTO providers(name,category,specialty,description) VALUES (?,?,?,?)',[
              ('Dr. Anjali Sharma','Doctor','General Physician','General consultation and routine health guidance.'),
              ('Dr. Rahul Mehta','Doctor','Dental Care','Dental consultation and follow-up visits.'),
              ('Glow & Style Studio','Salon','Hair & Beauty','Professional haircut and hair styling.'),
              ('Urban Looks Salon','Salon','Skin & Styling','Beauty, grooming and salon care.'),
              ('City Care Clinic','Clinic','General Clinic','Outpatient consultations and basic check-ups.'),
              ('Wellness Diagnostic Clinic','Clinic','Diagnostic Services','Health screening and report consultation.')])
            c.executemany('INSERT INTO services(provider_id,name,price,duration) VALUES (?,?,?,?)',[
              (1,'General Consultation',500,30),(1,'Follow-up Visit',300,20),(2,'Dental Consultation',600,30),(2,'Dental Check-up',400,20),
              (3,'Haircut',350,30),(3,'Hair Styling',650,45),(4,'Basic Facial',850,45),(4,'Hair Spa',1100,60),
              (5,'Clinic Consultation',450,30),(5,'Routine Check-up',350,20),(6,'Health Screening',800,40),(6,'Report Consultation',350,20)])
        c.commit()

def logged_in(fn):
    @wraps(fn)
    def inner(*args,**kwargs):
        if not session.get('uid'):
            flash('Please log in to book appointments.','warning')
            return redirect(url_for('login'))
        return fn(*args,**kwargs)
    return inner

@app.context_processor
def common():return dict(username=session.get('name'),today=date.today().isoformat())

@app.route('/')
def home():return render_template('home.html')

@app.route('/providers')
def providers():
    category=request.args.get('category','')
    if category and category not in ('Doctor','Salon','Clinic'):abort(404)
    if category:rows=db().execute('SELECT * FROM providers WHERE category=? ORDER BY name',(category,)).fetchall()
    else:rows=db().execute('SELECT * FROM providers ORDER BY category,name').fetchall()
    return render_template('providers.html',providers=rows,category=category)

@app.route('/provider/<int:pid>')
def provider(pid):
    item=db().execute('SELECT * FROM providers WHERE id=?',(pid,)).fetchone()
    if item is None:abort(404)
    services=db().execute('SELECT * FROM services WHERE provider_id=?',(pid,)).fetchall()
    return render_template('provider.html',item=item,services=services)

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        name=request.form.get('name','').strip();email=request.form.get('email','').strip().lower();password=request.form.get('password','')
        if not 2<=len(name)<=80 or not 5<=len(email)<=150 or '@' not in email or len(password)<8:
            flash('Enter valid details. Password must have at least 8 characters.','danger')
        else:
            try:
                with db():db().execute('INSERT INTO users(name,email,password_hash) VALUES (?,?,?)',(name,email,generate_password_hash(password)))
                flash('Account created. Please log in.','success');return redirect(url_for('login'))
            except sqlite3.IntegrityError:flash('Email already registered.','danger')
    return render_template('register.html')

@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        email=request.form.get('email','').strip().lower()
        user=db().execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
        if user and check_password_hash(user['password_hash'],request.form.get('password','')):
            session.clear();session['uid']=user['id'];session['name']=user['name']
            flash('Logged in successfully.','success');return redirect(url_for('appointments'))
        flash('Incorrect email or password.','danger')
    return render_template('login.html')

@app.route('/logout',methods=['POST'])
@logged_in
def logout():session.clear();flash('Logged out.','success');return redirect(url_for('home'))

@app.route('/book/<int:pid>',methods=['GET','POST'])
@logged_in
def book(pid):
    item=db().execute('SELECT * FROM providers WHERE id=?',(pid,)).fetchone()
    if item is None:abort(404)
    services=db().execute('SELECT * FROM services WHERE provider_id=?',(pid,)).fetchall()
    if request.method=='POST':
        try:
            sid=int(request.form.get('service_id',''));day=date.fromisoformat(request.form.get('day',''));slot=request.form.get('slot','')
            tm=datetime.strptime(slot,'%H:%M').time()
            if not db().execute('SELECT id FROM services WHERE id=? AND provider_id=?',(sid,pid)).fetchone():raise ValueError()
            if day<date.today() or day>date.today()+timedelta(days=90):raise ValueError()
            if tm.hour<9 or tm.hour>=18 or tm.minute not in (0,30):raise ValueError()
            if datetime.combine(day,tm)<=datetime.now():raise ValueError()
            with db():db().execute('INSERT INTO appointments(user_id,provider_id,service_id,booking_date,booking_time) VALUES (?,?,?,?,?)',(session['uid'],pid,sid,day.isoformat(),slot))
            flash('Appointment booked successfully!','success');return redirect(url_for('appointments'))
        except (ValueError,TypeError):flash('Select a valid service, future date and time.','danger')
        except sqlite3.IntegrityError:flash('This slot is already booked. Try another time.','warning')
    taken=[dict(x) for x in db().execute("SELECT booking_date,booking_time FROM appointments WHERE provider_id=? AND status='Confirmed' AND booking_date>=?",(pid,date.today().isoformat())).fetchall()]
    return render_template('book.html',item=item,services=services,taken=taken,max_date=(date.today()+timedelta(days=90)).isoformat())

@app.route('/appointments')
@logged_in
def appointments():
    rows=db().execute('''SELECT a.*,p.name AS provider_name,p.category,s.name AS service_name,s.price FROM appointments a JOIN providers p ON a.provider_id=p.id JOIN services s ON a.service_id=s.id WHERE a.user_id=? ORDER BY a.booking_date DESC,a.booking_time DESC''',(session['uid'],)).fetchall()
    return render_template('appointments.html',rows=rows)

@app.route('/cancel/<int:aid>',methods=['POST'])
@logged_in
def cancel(aid):
    with db():
        result=db().execute("UPDATE appointments SET status='Cancelled' WHERE id=? AND user_id=? AND status='Confirmed' AND (booking_date>? OR (booking_date=? AND booking_time>?))",(aid,session['uid'],date.today().isoformat(),date.today().isoformat(),datetime.now().strftime('%H:%M')))
    flash('Appointment cancelled.' if result.rowcount else 'This appointment cannot be cancelled.','success' if result.rowcount else 'warning')
    return redirect(url_for('appointments'))

@app.route('/health')
def health():return {'status':'ok','app':'Online Appointment Booking System'}

init_db()
if __name__=='__main__':app.run(debug=os.environ.get('FLASK_DEBUG')=='1')
