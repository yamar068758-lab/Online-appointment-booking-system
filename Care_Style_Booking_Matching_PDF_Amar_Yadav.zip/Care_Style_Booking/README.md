# Care & Style Booking — Matching PDF Website

This Flask website is designed to closely match the five *illustrative* website screens in the project report: Home, Registration, Login, Appointment Booking, and Appointment Status. The project report images are mockups, so the actual live pages are a functional interpretation rather than pixel-identical screenshots.

## Run locally (Python / Spyder)

1. Install Python 3.10+ and run `pip install -r requirements.txt`.
2. Open `app.py` in Spyder and run it, or use `python app.py` in a terminal.
3. Open the local URL printed by Flask (usually http://127.0.0.1:5000).
4. Register an account, log in, select Doctor/Salon/Clinic, choose a provider, book a future slot, and view/cancel it under My Appointments.

## Deploy (PythonAnywhere)

1. Upload and unzip this project folder.
2. Create a Flask web app and set the source folder to this folder.
3. Install `requirements.txt` in a virtual environment.
4. In the WSGI configuration use `from app import app as application` and ensure this folder is on `sys.path`.
5. Set `SECRET_KEY` to a strong random secret, and use a persistent writable `DATABASE_PATH` (absolute path). Set `COOKIE_SECURE=1` for HTTPS.
6. Reload the web app and test registration, booking, duplicate slot rejection and cancellation.

**Do not deploy to static-only hosting (e.g. Netlify drop): this app requires a running Flask server.**

## Notes

The report's screenshots are illustrations, not genuine deployed-site screenshots. Replace them with actual browser screenshots after successful deployment. Providers are fictional demonstration records. The prototype is not a production medical booking service.
