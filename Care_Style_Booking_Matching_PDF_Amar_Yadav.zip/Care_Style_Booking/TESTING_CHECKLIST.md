# Examiner demo checklist
1. Open home page, explain three service categories.
2. Open Doctors, Salon and Clinic lists.
3. Register a demo account (do not use a real personal password).
4. Log in.
5. Select a provider and service, choose a future date and available time.
6. Confirm booking, show My Appointments.
7. Attempt to book the same slot again; the system should reject it.
8. Cancel a future appointment and show Cancelled status.
9. Log out and log in again; the history should remain.

**Note:** These are suggested manual tests, not a claim that a live hosted deployment was tested.
